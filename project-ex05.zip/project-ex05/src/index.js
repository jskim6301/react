import {App} from './App';
document
    .getElementById('root')
    .appendChild(App());