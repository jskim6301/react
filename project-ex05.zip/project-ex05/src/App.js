const App = function(){
    const app = document.createElement('h1');
    app.textContent = 'Hello Webpack';

    return app;
}

export { App };